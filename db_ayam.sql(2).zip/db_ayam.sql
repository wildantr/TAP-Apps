-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 23. Juni 2015 jam 18:02
-- Versi Server: 5.1.37
-- Versi PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_ayam`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `nama`, `pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `dataayam`
--

CREATE TABLE IF NOT EXISTS `dataayam` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tgl` varchar(20) NOT NULL,
  `tgl_pem` varchar(30) NOT NULL,
  `umr` varchar(20) NOT NULL,
  `aymHdp` varchar(20) NOT NULL,
  `aymMti` varchar(20) NOT NULL,
  `pmvaksinan` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `dataayam`
--

INSERT INTO `dataayam` (`id`, `tgl`, `tgl_pem`, `umr`, `aymHdp`, `aymMti`, `pmvaksinan`) VALUES
(1, '2015-06-27', '', '7', '100', '0', '10'),
(2, '2015-06-20', '', 'Minggu ke-1', '20', '12', '1'),
(3, '2015-06-20', '2015-06-20', 'Minggu ke-3', '10', '15', '5'),
(4, '2015-06-20', '2015-06-20', 'Minggu ke-1', '187', '-87', '176'),
(5, '23 Juni 2015', '23 Juni 2015', 'Minggu ke-1', '70', '30', '2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `datakotoran`
--

CREATE TABLE IF NOT EXISTS `datakotoran` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tgl` varchar(20) NOT NULL,
  `bsh` varchar(20) NOT NULL,
  `kring` varchar(20) NOT NULL,
  `klkulasi` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `datakotoran`
--

INSERT INTO `datakotoran` (`id`, `tgl`, `bsh`, `kring`, `klkulasi`) VALUES
(1, '2015-06-20', '3', '2', '5'),
(2, '22 Juni 2015', '8', '9', '17'),
(3, '23 Juni 2015', '10', '9', '19'),
(4, '23 Juni 2015', '2', '2', '4');

-- --------------------------------------------------------

--
-- Struktur dari tabel `datatelur`
--

CREATE TABLE IF NOT EXISTS `datatelur` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tgl` varchar(20) NOT NULL,
  `brt` varchar(20) NOT NULL,
  `sht` varchar(20) NOT NULL,
  `cct` varchar(20) NOT NULL,
  `klkulasi` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `datatelur`
--

INSERT INTO `datatelur` (`id`, `tgl`, `brt`, `sht`, `cct`, `klkulasi`) VALUES
(1, '2015-06-03', '12300', '12300', '12300', '24600'),
(2, '2015-06-20', '15', '175', '5', '180'),
(3, '22 Juni 2015', '1', '3', '6', '9');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembellian`
--

CREATE TABLE IF NOT EXISTS `pembellian` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `modal` int(30) NOT NULL,
  `jumAnkAym` int(30) NOT NULL,
  `hrgAnkAym` int(30) NOT NULL,
  `jumPkn` int(30) NOT NULL,
  `hrgPkn` int(30) NOT NULL,
  `jumAir` int(30) NOT NULL,
  `hrgAir` int(30) NOT NULL,
  `jumListrik` int(30) NOT NULL,
  `hrgListrik` int(30) NOT NULL,
  `jumVaksin` int(30) NOT NULL,
  `hrgVaksin` int(30) NOT NULL,
  `hrgTotal` int(30) NOT NULL,
  `tgl` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `pembellian`
--

INSERT INTO `pembellian` (`id`, `modal`, `jumAnkAym`, `hrgAnkAym`, `jumPkn`, `hrgPkn`, `jumAir`, `hrgAir`, `jumListrik`, `hrgListrik`, `jumVaksin`, `hrgVaksin`, `hrgTotal`, `tgl`) VALUES
(1, 1000000, 100, 2500, 50, 750, 11, 150, 450, 10, 10, 2500, 0, '2015-06-20'),
(3, 1000000, 100, 2500, 50, 750, 11, 150, 450, 10, 10, 2500, 0, '2015-06-20'),
(4, 1000000, 100, 2500, 50, 750, 11, 150, 450, 10, 10, 2500, 293650, '2015-06-20'),
(5, 10000000, 100, 7000, 100, 5000, 100, 500, 450, 500, 15, 7000, 1700000, '23 Juni 2015');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE IF NOT EXISTS `penjualan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `jumAym` int(30) NOT NULL,
  `hrgAym` int(30) NOT NULL,
  `jumTelur` int(30) NOT NULL,
  `hrgTelur` int(30) NOT NULL,
  `jumKotoran` int(30) NOT NULL,
  `hrgKotoran` int(30) NOT NULL,
  `tl_jumAym` int(30) NOT NULL,
  `tl_jumTelur` int(30) NOT NULL,
  `tot_hrg_laku` int(30) NOT NULL,
  `tgl` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`id`, `jumAym`, `hrgAym`, `jumTelur`, `hrgTelur`, `jumKotoran`, `hrgKotoran`, `tl_jumAym`, `tl_jumTelur`, `tot_hrg_laku`, `tgl`) VALUES
(2, 100, 25000, 20, 12000, 10, 1000, 10, 15, 2750000, '22 Juni 2015'),
(3, 10, 20, 10, 21, 10, 78, 89, 56, 1190, '22 Juni 2015');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
